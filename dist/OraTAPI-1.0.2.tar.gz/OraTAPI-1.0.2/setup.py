from setuptools import setup, find_packages

def parse_requirements(filename):
    with open(filename, 'r') as file:
        return [line.strip() for line in file.readlines() if line.strip()]

setup(
    name="OraTAPI",
    version="1.0.2",
    # Automatically discover Python packages in your project
    packages=find_packages(
        where='.',  # Search in the current directory and subdirectories
        include=['controller', 'lib', 'model', 'view', 'templates', 'utils'],  # Specify directories to include
    ),
    # Include shell scripts and other non-Python files
    data_files=[
        ('bin', ['bin/ora_tapi.sh', 'bin/conn_mgr.sh']),
        ('config', ['config/OraTAPI.ini']),
    ],
    install_requires=parse_requirements('requirements.txt'),
    entry_points={
        "console_scripts": [
            "ora_tapi=controller.ora_tapi:main",  # Adjust the entry point to the actual function
            "conn_mgr=controller.conn_mgr:main",  # Likewise for conn_mgr
        ],
    },
    include_package_data=True,  # Ensure package data is included when using find_packages
)

